"""
Flask interface for CampusConnect.

This file is a THIN layer: it parses HTTP requests, calls the core Engine, and
returns JSON. All graph/DSA logic lives in core/engine.py and core/graph.py.

Run:  python app.py      then open http://127.0.0.1:5000
"""
import os
import secrets
import uuid
from functools import wraps

from flask import Flask, jsonify, render_template, request, session

from core.engine import Engine, NetError

BASE = os.path.dirname(os.path.abspath(__file__))
UPLOADS = os.path.join(BASE, "static", "uploads")
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "webp"}


def load_secret():
    """Persist a random session key so logins survive a restart."""
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    path = os.path.join(BASE, "secret.key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
    with open(path) as f:
        return f.read().strip()


def create_app(db_path=None):
    app = Flask(__name__)
    app.secret_key = load_secret()
    app.config["MAX_CONTENT_LENGTH"] = 3 * 1024 * 1024      # 3 MB uploads
    app.config["TEMPLATES_AUTO_RELOAD"] = True
    engine = Engine(db_path or os.path.join(BASE, "campusconnect.db"))
    os.makedirs(UPLOADS, exist_ok=True)

    # ---------------- helpers ---------------- #
    def login_required(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            user = session.get("user")
            if not user or user not in engine.users:
                return jsonify(error="Please log in"), 401
            return fn(user, *a, **kw)
        return wrapper

    @app.errorhandler(NetError)
    def on_net_error(err):
        return jsonify(error=str(err)), 400

    @app.errorhandler(413)
    def too_big(_):
        return jsonify(error="Image too large (max 3 MB)"), 413

    def body():
        return request.get_json(silent=True) or {}

    # ---------------- pages ---------------- #
    @app.get("/")
    def index():
        return render_template("index.html")

    # ---------------- accounts ---------------- #
    @app.post("/api/signup")
    def signup():
        d = body()
        u = engine.signup(d.get("username"), d.get("password"), d.get("name"),
                          d.get("programme", ""), d.get("year", 1),
                          d.get("bio", ""), d.get("skills", ""))
        session["user"] = u
        return jsonify(user=u)

    @app.post("/api/login")
    def login():
        d = body()
        session["user"] = engine.login(d.get("username"), d.get("password"))
        return jsonify(user=session["user"])

    @app.post("/api/logout")
    def logout():
        user = session.pop("user", None)
        if user in engine.users:
            engine.logout(user)
        return jsonify(ok=True)

    @app.get("/api/me")
    def me():
        user = session.get("user")
        if not user or user not in engine.users:
            return jsonify(user=None)
        return jsonify(user=user, profile=engine.users[user].profile(),
                       unread=engine.unread_count(user),
                       incoming=len(engine.requests_in[user]))

    @app.put("/api/profile")
    @login_required
    def update_profile(user):
        d = body()
        return jsonify(engine.update_profile(user, d.get("name"), d.get("programme"),
                                             d.get("year"), d.get("bio"), d.get("skills")))

    @app.get("/api/profile/<target>")
    @login_required
    def profile(user, target):
        return jsonify(engine.get_profile(user, target))

    @app.post("/api/back")
    @login_required
    def back(user):
        return jsonify(profile=engine.back(user))

    # ---------------- connections ---------------- #
    @app.get("/api/connections")
    @login_required
    def connections(user):
        return jsonify(engine.connections(user))

    @app.get("/api/requests")
    @login_required
    def requests_(user):
        return jsonify(incoming=engine.incoming_requests(user),
                       outgoing=engine.outgoing_requests(user))

    @app.post("/api/request/<other>")
    @login_required
    def send_request(user, other):
        engine.send_request(user, other)
        return jsonify(ok=True)

    @app.post("/api/accept/<other>")
    @login_required
    def accept(user, other):
        engine.accept_request(user, other)
        return jsonify(ok=True)

    @app.post("/api/reject/<other>")
    @login_required
    def reject(user, other):
        engine.reject_request(user, other)
        return jsonify(ok=True)

    @app.post("/api/cancel/<other>")
    @login_required
    def cancel(user, other):
        engine.cancel_request(user, other)
        return jsonify(ok=True)

    @app.delete("/api/connection/<other>")
    @login_required
    def remove(user, other):
        engine.remove_connection(user, other)
        return jsonify(ok=True)

    @app.get("/api/mutual/<other>")
    @login_required
    def mutual(user, other):
        return jsonify(engine.mutual_connections(user, other))

    @app.get("/api/suggestions")
    @login_required
    def suggestions(user):
        return jsonify(engine.suggestions(user))

    @app.get("/api/students")
    @login_required
    def students(user):
        sug_map = {s["username"]: s for s in engine.suggestions(user, k=50)}
        conns = engine.graph.neighbors(user)
        out = list(sug_map.values())
        for uname in sorted(engine.users, key=lambda u: engine.users[u].name.lower()):
            if uname == user or uname in conns or uname in sug_map:
                continue
            d = engine.users[uname].summary()
            d.update({
                "score": 0.0,
                "mutual_count": len(engine.graph.mutual(user, uname)),
                "relation": engine.relation(user, uname),
            })
            out.append(d)
        for item in out:
            item.setdefault("relation", engine.relation(user, item["username"]))
        return jsonify(out)

    @app.get("/api/degree/<other>")
    @login_required
    def degree(user, other):
        engine._user(other)
        return jsonify(engine.connection_info(user, other))

    @app.get("/api/communities")
    @login_required
    def communities(user):
        return jsonify(engine.communities(user))

    # ---------------- posts ---------------- #
    @app.post("/api/posts")
    @login_required
    def create_post(user):
        if request.files or request.form:
            text = request.form.get("text", "")
            image = None
            f = request.files.get("image")
            if f and f.filename:
                ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
                if ext not in ALLOWED_EXT:
                    raise NetError("Image must be png, jpg, gif or webp")
                name = f"{uuid.uuid4().hex}.{ext}"
                f.save(os.path.join(UPLOADS, name))
                image = f"/static/uploads/{name}"
        else:
            text, image = body().get("text", ""), None
        try:
            return jsonify(engine.create_post(user, text, image))
        except NetError:
            if image:
                os.remove(os.path.join(UPLOADS, os.path.basename(image)))
            raise

    @app.get("/api/posts/user/<target>")
    @login_required
    def user_posts(user, target):
        return jsonify(engine.user_posts(user, target))

    @app.delete("/api/posts/<int:pid>")
    @login_required
    def delete_post(user, pid):
        image = engine.delete_post(user, pid)
        if image:
            try:
                os.remove(os.path.join(UPLOADS, os.path.basename(image)))
            except OSError:
                pass
        return jsonify(ok=True)

    @app.get("/api/feed")
    @login_required
    def feed(user):
        return jsonify(engine.feed(user))

    @app.get("/api/trending")
    @login_required
    def trending(user):
        return jsonify(engine.trending(user))

    @app.post("/api/posts/<int:pid>/like")
    @login_required
    def like(user, pid):
        n, liked = engine.toggle_like(user, pid)
        return jsonify(likes=n, liked=liked)

    @app.post("/api/posts/<int:pid>/comments")
    @login_required
    def comment(user, pid):
        d = body()
        return jsonify(engine.add_comment(user, pid, d.get("text"), d.get("parent", 0)))

    # ---------------- notifications & search ---------------- #
    @app.get("/api/notifications")
    @login_required
    def notifications(user):
        return jsonify(engine.notifications(user))

    @app.get("/api/search")
    @login_required
    def search(user):
        return jsonify(engine.search(request.args.get("q", "")))

    return app


if __name__ == "__main__":
    create_app().run(debug=False, port=int(os.environ.get("PORT", 5000)))
