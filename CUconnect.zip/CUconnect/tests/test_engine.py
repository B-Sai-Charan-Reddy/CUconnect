import os
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.engine import Engine, NetError   # noqa: E402
from core.ds import Trie, Queue, Stack       # noqa: E402
from core.graph import Graph                 # noqa: E402


def make(e, *names):
    for n in names:
        e.signup(n, "secret1", n.capitalize() + " Test", "CSE", 3)


def connect(e, a, b):
    e.send_request(a, b)
    e.accept_request(b, a)


class DataStructureTests(unittest.TestCase):
    def test_trie(self):
        t = Trie()
        t.insert("alice", "alice"); t.insert("alan", "alan"); t.insert("bob", "bob")
        self.assertEqual(t.starts_with("al"), ["alan", "alice"])
        self.assertEqual(t.starts_with("AL"), ["alan", "alice"])
        self.assertEqual(t.starts_with("z"), [])
        self.assertEqual(len(t.starts_with("a", limit=1)), 1)
        t.remove("alan", "alan")
        self.assertEqual(t.starts_with("al"), ["alice"])

    def test_queue_stack(self):
        q = Queue(); q.enqueue(1); q.enqueue(2); q.enqueue(3)
        self.assertEqual(q.dequeue(), 1)
        q.remove(3)
        self.assertEqual(list(q), [2])
        s = Stack(); s.push("a"); s.push("b")
        self.assertEqual(s.pop(), "b"); self.assertEqual(s.peek(), "a")

    def test_graph_rules(self):
        g = Graph()
        with self.assertRaises(ValueError):
            g.add_edge("a", "a")
        g.add_edge("a", "b"); g.add_edge("b", "a")      # duplicate ignored
        self.assertEqual(g.degree("a"), 1)

    def test_bfs_and_degrees(self):
        g = Graph()
        for u, v in [("a", "b"), ("b", "c"), ("c", "d"), ("a", "e"), ("e", "d")]:
            g.add_edge(u, v)
        g.add_node("z")
        self.assertEqual(g.degree_of_connection("a", "b"), 1)
        self.assertEqual(g.degree_of_connection("a", "c"), 2)
        self.assertEqual(g.degree_of_connection("a", "d"), 2)     # via e
        self.assertEqual(len(g.shortest_path("a", "d")), 3)
        self.assertIsNone(g.shortest_path("a", "z"))

    def test_cliques(self):
        g = Graph()
        for u, v in [("a", "b"), ("b", "c"), ("a", "c"), ("c", "d")]:
            g.add_edge(u, v)
        self.assertEqual(g.cliques_containing("a"), [["a", "b", "c"]])


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.e = Engine(":memory:")
        make(self.e, "ann", "bob", "cat", "dan", "eve")

    def test_accounts(self):
        with self.assertRaises(NetError): self.e.signup("ann", "secret1", "X")
        with self.assertRaises(NetError): self.e.signup("new", "123", "X")
        with self.assertRaises(NetError): self.e.login("ann", "wrong")
        self.assertEqual(self.e.login("ann", "secret1"), "ann")
        self.assertNotIn("secret1", self.e.users["ann"].pw_hash)

    def test_request_lifecycle(self):
        e = self.e
        e.send_request("ann", "bob")
        with self.assertRaises(NetError): e.send_request("ann", "bob")
        with self.assertRaises(NetError): e.send_request("bob", "ann")
        with self.assertRaises(NetError): e.send_request("ann", "ann")
        self.assertEqual(e.relation("ann", "bob"), "pending_out")
        e.cancel_request("ann", "bob")
        e.send_request("ann", "bob"); e.reject_request("bob", "ann")
        self.assertEqual(e.relation("ann", "bob"), "none")
        connect(e, "ann", "bob")
        self.assertEqual(e.relation("bob", "ann"), "connected")
        with self.assertRaises(NetError): e.send_request("bob", "ann")
        e.remove_connection("ann", "bob")
        self.assertEqual(e.relation("ann", "bob"), "none")

    def test_mutual_degree_suggestions(self):
        e = self.e
        connect(e, "ann", "bob"); connect(e, "bob", "cat"); connect(e, "cat", "dan")
        connect(e, "ann", "eve"); connect(e, "eve", "cat")
        self.assertEqual([m["username"] for m in e.mutual_connections("ann", "cat")], ["bob", "eve"])
        self.assertEqual(e.connection_info("ann", "cat")["degree"], 2)
        self.assertEqual(e.connection_info("ann", "dan")["degree"], 3)
        self.assertEqual(e.connection_info("ann", "dan")["label"], "3rd degree connection")
        self.assertEqual(e.suggestions("ann")[0]["username"], "cat")
        # pending request removes candidate from suggestions
        e.send_request("ann", "cat")
        self.assertEqual(e.suggestions("ann"), [])

    def test_feed_order_and_delete(self):
        e = self.e
        connect(e, "ann", "bob"); connect(e, "ann", "cat")
        e.create_post("bob", "b1"); time.sleep(0.01)
        e.create_post("cat", "c1"); time.sleep(0.01)
        e.create_post("bob", "b2"); time.sleep(0.01)
        e.create_post("dan", "not connected")
        self.assertEqual([p["text"] for p in e.feed("ann")], ["b2", "c1", "b1"])
        pid = e.feed("ann")[0]["id"]
        with self.assertRaises(NetError): e.delete_post("ann", pid)
        e.delete_post("bob", pid)
        self.assertEqual([p["text"] for p in e.feed("ann")], ["c1", "b1"])

    def test_likes_comments_notifications_trending(self):
        e = self.e
        connect(e, "ann", "bob")
        p = e.create_post("bob", "hello")
        self.assertEqual(e.toggle_like("ann", p["id"]), (1, True))
        c = e.add_comment("ann", p["id"], "nice")
        e.add_comment("bob", p["id"], "thanks", parent=c["id"])
        view = e.user_posts("ann", "bob")[0]
        self.assertEqual(view["comment_count"], 2)
        self.assertEqual(view["comments"][0]["replies"][0]["text"], "thanks")
        n = e.notifications("bob")
        self.assertGreaterEqual(n["unread"], 3)   # request accepted? (ann->bob), like, comment
        self.assertEqual(e.unread_count("bob"), 0)
        self.assertEqual(e.trending("ann")[0]["id"], p["id"])
        self.assertEqual(e.toggle_like("ann", p["id"]), (0, False))

    def test_search(self):
        e = self.e
        e.signup("anil.rao", "secret1", "Anil Rao")
        names = [u["username"] for u in e.search("an")]
        self.assertIn("anil.rao", names); self.assertIn("ann", names)
        self.assertEqual([u["username"] for u in e.search("rao")], ["anil.rao"])
        self.assertEqual([u["username"] for u in e.search("anil r")], ["anil.rao"])
        self.assertEqual(e.search(""), [])

    def test_back_navigation(self):
        e = self.e
        e.get_profile("ann", "bob"); e.get_profile("ann", "cat"); e.get_profile("ann", "dan")
        self.assertEqual(e.back("ann")["username"], "cat")
        self.assertEqual(e.back("ann")["username"], "bob")
        self.assertIsNone(e.back("ann"))

    def test_persistence(self):
        path = os.path.join(tempfile.mkdtemp(), "t.db")
        e = Engine(path)
        make(e, "ann", "bob", "cat")
        connect(e, "ann", "bob"); e.send_request("cat", "ann")
        p = e.create_post("bob", "persist me")
        e.toggle_like("ann", p["id"]); e.add_comment("ann", p["id"], "c")
        e2 = Engine(path)                                   # simulate restart
        self.assertTrue(e2.graph.has_edge("ann", "bob"))
        self.assertEqual(e2.relation("cat", "ann"), "pending_out")
        self.assertEqual(e2.feed("ann")[0]["text"], "persist me")
        self.assertEqual(e2.feed("ann")[0]["likes"], 1)
        self.assertEqual(e2.feed("ann")[0]["comment_count"], 1)
        self.assertEqual(e2.login("ann", "secret1"), "ann")
        self.assertEqual([u["username"] for u in e2.search("c")], ["cat"])


if __name__ == "__main__":
    unittest.main()
