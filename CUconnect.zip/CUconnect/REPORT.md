---
title: "CampusConnect: A Student Networking App"
subtitle: "Mini-Project, Data Structures and Algorithms, III Semester B.Tech (2026-27), Chanakya University"
---

**Team members:** *(add names and USNs)*  
**GitHub repository:** *(add link)*  
**Note:** adapt headings to the department's standard report template before submitting.

# 1. Introduction

CampusConnect is a networking app for Chanakya University students. Students create a profile, share posts about their projects and technical ideas, and connect with one another. The goal of the project is to show how the right data structure makes each feature simple and fast. The social network is modelled as a graph and almost every feature is a graph or data-structure operation.

# 2. Problem model

The network is a graph G(V, E). Each user is a node in V. Each accepted connection is an undirected edge in E. A pending request is a directed edge from sender to receiver until it is accepted (it becomes an undirected edge) or rejected/cancelled (it disappears). There are no self edges and no multiple edges.

# 3. System design

The code is split into layers so the core engine can be reused by any interface.

| Layer | Files | Responsibility |
|---|---|---|
| Data structures | `core/ds.py`, `core/graph.py` | Trie, Queue, Stack, Graph and its algorithms |
| Engine | `core/engine.py` | All application logic; holds the in-memory structures |
| Storage | `core/storage.py` | SQLite read/write only |
| Interface | `app.py`, `templates/index.html` | Flask REST API and web page |

**Persistence strategy.** SQLite only stores the data. At start-up the engine loads all rows once and rebuilds the in-memory structures (graph, queues, trie, post lists). After that each change updates memory first and is then written through to SQLite. All graph computations (suggestions, degrees, paths, feed) run on the in-memory structures and never use SQL queries.

# 4. Data structures and algorithms used

Let V = number of users, E = number of connections, d = degree of a user, k = number of connections of a user, L = key length, n = number of posts considered.

| Feature | Structure / algorithm | Why this choice | Complexity |
|---|---|---|---|
| User lookup, login | Hash table (`dict`) | Constant-time lookup by unique username | O(1) average |
| Network storage | Adjacency lists (`dict` of `set`) | Sparse graph (E much less than V squared); sets prevent duplicate edges and give O(1) edge tests | Space O(V + E) |
| Degree of connection, shortest chain | Breadth-first search with parent map | BFS finds shortest paths in an unweighted graph; parents rebuild the chain | O(V + E) |
| Mutual connections | Set intersection of two adjacency lists | Direct, fast | O(min(d_a, d_b)) |
| People you may know | Candidates = friends of friends; rank by Jaccard similarity \|N(a) ∩ N(b)\| / \|N(a) ∪ N(b)\|, ties by mutual count | Avoids scanning the whole graph; Jaccard normalises for popular users | O(sum of neighbours' degrees) |
| Pending requests | Queue (FIFO, `collections.deque`) | Requests are handled in arrival order | O(1) enqueue; O(k) remove |
| Home feed | K-way merge using a min-heap (`heapq`) | Each connection already has a time-ordered list; a heap of "newest unseen post per connection" yields the global order without sorting everything | O(k + m log k) for m posts shown |
| Search as you type | Trie | Prefix lookup cost depends on prefix length, not on the number of users | O(L + results) |
| Back navigation | Stack | Last viewed profile is the first one returned to | O(1) |
| Trending posts | Heap (`heapq.nlargest`) with score (likes + 2 x comments) / (age in hours + 2)^1.5 | Top-k without sorting everything | O(n log k) |
| Comments and replies | Tree (each comment stores parent and child ids) | Replies to replies nest naturally | O(size) to render |
| Circles (groups) | Bron-Kerbosch maximal cliques on the user's ego network | Finds sets of students who are all connected to each other | Exponential worst case, small on ego networks |
| Passwords | PBKDF2-HMAC-SHA256 with a random salt (`hashlib`) | Hashes only; the same password gives different hashes | n/a |

**Worked example (shortest chain).** Aarav is connected to Kabir, and Kabir to Sneha. BFS from Aarav visits Kabir at depth 1 and Sneha at depth 2, so the app shows "2nd degree connection" and the chain Aarav -> Kabir -> Sneha.

**Worked example (suggestions).** Aarav's neighbours are {Diya, Kabir, Tara}; Sneha's are {Kabir, Tara, Ananya}. Intersection = 2, union = 4, so Jaccard = 0.5, the highest score among Aarav's non-connections, so Sneha is suggested first.

# 5. Features implemented

**Core requirements (all six parts):**

1. Accounts: sign up, log in, log out, hashed passwords, profile (name, programme, year, bio, skills) viewable by others.
2. Connections: send, accept, reject, cancel, remove; connection list; mutual connections; people you may know; degree of connection and shortest chain; adjacency lists.
3. Posts and feed: text posts, view and delete own posts, home feed newest first.
4. Search: prefix search on username and name with suggestions while typing.
5. Persistence: SQLite, all data survives a restart.
6. Interface: Flask REST API with a web front end; core engine separate from the interface.

**Enhancements:** image posts, likes, comments with nested replies, notifications (requests, accepted, likes, comments), trending posts, circles of closely connected students, profile back-navigation.

# 6. Testing

A suite of 13 unit tests (`tests/test_engine.py`) covers the trie, queue, stack, graph rules (no self or duplicate edges), BFS and degrees, cliques, account validation, the full request lifecycle, mutual connections, suggestions, feed ordering and deletion, likes/comments/notifications/trending, search, back navigation and a simulated restart that checks persistence. A separate smoke test exercised the REST API end to end (login protection, requests, image upload, feed, like, comment, delete). All tests pass.

# 7. Limitations and future work

- Passwords are salted and hashed, but the app has no rate limiting, e-mail verification or HTTPS configuration; it is meant for a classroom demo.
- The graph is held fully in memory, which suits a campus-sized network (thousands of users) but not millions.
- Suggestions use Jaccard similarity only. Katz score or weighted paths could be added.
- Possible extensions: direct messages, group pages, skill-based recommendations, a console front end calling the same engine.

# 8. How to run

```
pip install -r requirements.txt
python app.py      # http://127.0.0.1:5000
python -m unittest discover -s tests -v
```
