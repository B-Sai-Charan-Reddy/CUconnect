# CampusConnect

A networking app for Chanakya University students (in the spirit of LinkedIn / Instagram).
Students share projects and technical ideas and connect with each other.
Mini-project for **Data Structures and Algorithms**, III Semester B.Tech, 2026-27.

The user network is modelled as a graph **G(V, E)**: every user is a node, every accepted
connection is an undirected edge, and a pending request is a directed edge (sender -> receiver)
until it is accepted or rejected. No self edges, no multiple edges.

## Run it

```bash
pip install -r requirements.txt
python app.py         # open http://127.0.0.1:5000
python -m unittest discover -s tests -v    # run the tests
```

## Project layout

```
campusconnect/
  core/                 <- the core engine (no Flask, no UI code)
    ds.py               Trie, Queue, Stack (written from scratch)
    graph.py            adjacency-list graph, BFS, Jaccard, cliques
    engine.py           all application logic + in-memory structures
    storage.py          SQLite: only stores / loads rows
  app.py                Flask REST API (thin layer over the engine)
  templates/index.html  single-page web UI (vanilla JS)
  tests/test_engine.py  13 unit tests
  REPORT.md / .docx     project report
```

## Requirement -> data structure map

| Feature | Data structure / algorithm | Where |
|---|---|---|
| User lookup | Hash table (`dict`) | `Engine.users` |
| Network | Adjacency lists (`dict` of `set`) | `Graph.adj` |
| Degree of connection, shortest chain | BFS | `Graph.shortest_path` |
| Mutual connections | Set intersection | `Graph.mutual` |
| People you may know | Jaccard similarity, 2-hop candidates | `Graph.suggestions` |
| Pending requests | Queue (FIFO) | `Engine.requests_in`, `ds.Queue` |
| Home feed | k-way merge with a min-heap (`heapq`) | `Engine.feed` |
| Search as you type | Trie (prefix search) | `ds.Trie` |
| Back navigation | Stack | `Engine.history`, `ds.Stack` |
| Trending posts | Heap (`heapq.nlargest`) with engagement/age score | `Engine.trending` |
| Comment replies | Tree (parent / children ids) | `Engine.comments` |
| Groups / circles | Bron-Kerbosch maximal cliques on ego network | `Graph.cliques_containing` |
| Notifications | Per-user FIFO list, persisted | `Engine.notifs` |

## How requirements are met

- **Accounts**: unique username, PBKDF2-SHA256 salted hash (`hashlib`), never plain text; profile with name, programme, year, bio, skills.
- **Connections**: send / accept / reject / cancel / remove; connection list; mutual connections; people you may know; degree (1st, 2nd, 3rd...) + one shortest chain.
- **Posts and feed**: text (and optional image) posts, view/delete own posts, feed from connections newest first.
- **Search**: prefix search on username, full name and each word of the name.
- **Persistence**: SQLite. On start-up everything is loaded into memory; **all graph computations run on in-memory structures, not SQL**.
- **Interface**: Flask + HTML/JS. Core engine is separate, so a console front end could call the same functions.
- **Enhancements**: image posts, likes, nested comments/replies, notifications, trending, circles.
