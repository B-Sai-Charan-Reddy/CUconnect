"""
Basic data structures used by the CampusConnect engine.

Everything here is written from scratch (except heapq, used in engine.py for the
priority queue) so each structure can be explained line by line in the viva.

  Trie   - prefix search for names / usernames       O(L) insert, O(L + k) search
  Queue  - FIFO queue (pending requests)             O(1) enqueue/dequeue
  Stack  - LIFO stack (profile back-navigation)      O(1) push/pop
"""
from collections import deque


# --------------------------------------------------------------------------- #
# Trie
# --------------------------------------------------------------------------- #
class TrieNode:
    __slots__ = ("children", "values")

    def __init__(self):
        self.children = {}      # char -> TrieNode
        self.values = set()     # usernames whose key ends exactly at this node


class Trie:
    """Maps string keys to sets of values (usernames). Case-insensitive."""

    def __init__(self):
        self.root = TrieNode()

    def insert(self, key, value):
        node = self.root
        for ch in key.lower():
            if ch not in node.children:
                node.children[ch] = TrieNode()
            node = node.children[ch]
        node.values.add(value)

    def remove(self, key, value):
        node = self.root
        for ch in key.lower():
            node = node.children.get(ch)
            if node is None:
                return
        node.values.discard(value)

    def starts_with(self, prefix, limit=10):
        """Return up to `limit` distinct values whose key starts with prefix."""
        node = self.root
        for ch in prefix.lower():
            node = node.children.get(ch)
            if node is None:
                return []
        found, seen = [], set()
        self._collect(node, found, seen, limit)
        return found

    def _collect(self, node, found, seen, limit):
        # Depth-first, children visited alphabetically so output is deterministic.
        for v in sorted(node.values):
            if v not in seen:
                seen.add(v)
                found.append(v)
                if len(found) >= limit:
                    return
        for ch in sorted(node.children):
            if len(found) >= limit:
                return
            self._collect(node.children[ch], found, seen, limit)


# --------------------------------------------------------------------------- #
# Queue (FIFO)
# --------------------------------------------------------------------------- #
class Queue:
    """FIFO queue built on collections.deque (O(1) at both ends)."""

    def __init__(self):
        self._d = deque()

    def enqueue(self, item):
        self._d.append(item)

    def dequeue(self):
        if not self._d:
            raise IndexError("dequeue from empty queue")
        return self._d.popleft()

    def remove(self, item):
        """Remove an arbitrary item (used for accept / reject / cancel). O(n)."""
        try:
            self._d.remove(item)
            return True
        except ValueError:
            return False

    def __contains__(self, item):
        return item in self._d

    def __iter__(self):
        return iter(self._d)

    def __len__(self):
        return len(self._d)


# --------------------------------------------------------------------------- #
# Stack (LIFO)
# --------------------------------------------------------------------------- #
class Stack:
    def __init__(self):
        self._items = []

    def push(self, item):
        self._items.append(item)

    def pop(self):
        if not self._items:
            raise IndexError("pop from empty stack")
        return self._items.pop()

    def peek(self):
        return self._items[-1] if self._items else None

    def __len__(self):
        return len(self._items)
