"""
SQLite persistence layer. It ONLY stores and loads rows - no graph logic here.
On start-up the engine reads everything once and rebuilds its in-memory
structures; afterwards every change is written through.
"""
import sqlite3
import threading

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    username TEXT PRIMARY KEY, pw_hash TEXT NOT NULL, salt TEXT NOT NULL,
    name TEXT, programme TEXT, year INTEGER, bio TEXT, skills TEXT);
CREATE TABLE IF NOT EXISTS connections(
    a TEXT NOT NULL, b TEXT NOT NULL, PRIMARY KEY(a, b));
CREATE TABLE IF NOT EXISTS requests(
    sender TEXT NOT NULL, receiver TEXT NOT NULL, ts REAL, PRIMARY KEY(sender, receiver));
CREATE TABLE IF NOT EXISTS posts(
    id INTEGER PRIMARY KEY AUTOINCREMENT, author TEXT, text TEXT, image TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS likes(
    post_id INTEGER, user TEXT, PRIMARY KEY(post_id, user));
CREATE TABLE IF NOT EXISTS comments(
    id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER, author TEXT,
    parent_id INTEGER, text TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS notifications(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, kind TEXT, text TEXT,
    ts REAL, is_read INTEGER DEFAULT 0);
"""


class Storage:
    def __init__(self, path="campusconnect.db"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    def run(self, sql, args=()):
        """Execute a write statement and commit. Returns the cursor."""
        with self.lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    def all(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args).fetchall()
