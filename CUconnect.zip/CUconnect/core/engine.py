"""
CampusConnect core engine.

This module holds ALL the application logic and knows nothing about Flask or
the console, so any interface can call the same functions.

Data structures (see REPORT.md for justification):
  users            dict (hash table)       username -> User        O(1) lookup
  graph            adjacency lists         accepted connections    BFS, Jaccard
  requests_in      dict of Queue           pending requests (FIFO) per receiver
  requests_out     dict of set             who each user has asked
  name_index       Trie                    prefix search by name/username
  posts_by_user    dict of sorted lists    per-user posts, oldest -> newest
  feed()           min-heap k-way merge    home feed, newest first
  trending()       heap (nlargest)         top posts by engagement score
  history          dict of Stack           profile back-navigation
  comments         tree (parent/children)  nested replies
"""
import hashlib
import heapq
import hmac
import os
import re
import time
from dataclasses import dataclass, field

from .ds import Queue, Stack, Trie
from .graph import Graph
from .storage import Storage

USERNAME_RE = re.compile(r"^[a-z0-9_.]{3,20}$")


class NetError(Exception):
    """User-facing error (bad input, not allowed, not found...)."""


# --------------------------------------------------------------------------- #
# Records
# --------------------------------------------------------------------------- #
@dataclass
class User:
    username: str
    pw_hash: str
    salt: str
    name: str = ""
    programme: str = ""
    year: int = 1
    bio: str = ""
    skills: list = field(default_factory=list)

    def summary(self):
        return {"username": self.username, "name": self.name,
                "programme": self.programme, "year": self.year}

    def profile(self):
        d = self.summary()
        d.update({"bio": self.bio, "skills": self.skills})
        return d


@dataclass
class Post:
    id: int
    author: str
    text: str
    image: str
    ts: float
    likes: set = field(default_factory=set)
    comment_ids: list = field(default_factory=list)   # top-level comment ids


@dataclass
class Comment:
    id: int
    post_id: int
    author: str
    parent: int          # 0 for top-level
    text: str
    ts: float
    children: list = field(default_factory=list)      # reply ids


# --------------------------------------------------------------------------- #
# Password hashing (never store plain text)
# --------------------------------------------------------------------------- #
def hash_password(password, salt_hex):
    return hashlib.pbkdf2_hmac("sha256", password.encode(),
                               bytes.fromhex(salt_hex), 100_000).hex()


def ordinal(n):
    return {1: "1st", 2: "2nd", 3: "3rd"}.get(n, f"{n}th")


# --------------------------------------------------------------------------- #
# Engine
# --------------------------------------------------------------------------- #
class Engine:
    def __init__(self, db_path="campusconnect.db"):
        self.db = Storage(db_path)
        self.users = {}
        self.graph = Graph()
        self.requests_in = {}       # receiver -> Queue[sender]
        self.requests_out = {}      # sender   -> set(receiver)
        self.name_index = Trie()
        self.posts = {}             # id -> Post
        self.posts_by_user = {}     # user -> [post ids, ascending]
        self.comments = {}          # id -> Comment
        self.history = {}           # user -> Stack of viewed usernames
        self.notifs = {}            # user -> list of dicts (oldest first)
        self._load()

    # ------------------------------------------------------------------ #
    # Start-up: rebuild every in-memory structure from the database
    # ------------------------------------------------------------------ #
    def _load(self):
        for r in self.db.all("SELECT * FROM users"):
            u = User(r["username"], r["pw_hash"], r["salt"], r["name"],
                     r["programme"], r["year"], r["bio"],
                     [s for s in (r["skills"] or "").split(",") if s])
            self._register(u)
        for r in self.db.all("SELECT a, b FROM connections"):
            self.graph.add_edge(r["a"], r["b"])
        for r in self.db.all("SELECT sender, receiver FROM requests ORDER BY ts"):
            self.requests_in[r["receiver"]].enqueue(r["sender"])
            self.requests_out[r["sender"]].add(r["receiver"])
        for r in self.db.all("SELECT * FROM posts ORDER BY id"):
            p = Post(r["id"], r["author"], r["text"], r["image"], r["ts"])
            self.posts[p.id] = p
            self.posts_by_user[p.author].append(p.id)
        for r in self.db.all("SELECT post_id, user FROM likes"):
            self.posts[r["post_id"]].likes.add(r["user"])
        for r in self.db.all("SELECT * FROM comments ORDER BY id"):
            c = Comment(r["id"], r["post_id"], r["author"], r["parent_id"] or 0,
                        r["text"], r["ts"])
            self.comments[c.id] = c
            if c.parent:
                self.comments[c.parent].children.append(c.id)
            else:
                self.posts[c.post_id].comment_ids.append(c.id)
        for r in self.db.all("SELECT * FROM notifications ORDER BY id"):
            self.notifs[r["user"]].append(
                {"id": r["id"], "kind": r["kind"], "text": r["text"],
                 "ts": r["ts"], "read": bool(r["is_read"])})

    def _register(self, u):
        """Create the empty per-user structures and index the user's names."""
        self.users[u.username] = u
        self.graph.add_node(u.username)
        self.requests_in[u.username] = Queue()
        self.requests_out[u.username] = set()
        self.posts_by_user[u.username] = []
        self.notifs[u.username] = []
        self.history[u.username] = Stack()
        self._index(u)

    def _keys(self, u):
        # username, full name, and every word of the name can start a search
        return {u.username, u.name.lower(), *u.name.lower().split()} - {""}

    def _index(self, u):
        for k in self._keys(u):
            self.name_index.insert(k, u.username)

    def _unindex(self, u):
        for k in self._keys(u):
            self.name_index.remove(k, u.username)

    # ------------------------------------------------------------------ #
    # Part 1: Accounts
    # ------------------------------------------------------------------ #
    def signup(self, username, password, name, programme="", year=1, bio="", skills=()):
        username = (username or "").strip().lower()
        if not USERNAME_RE.match(username):
            raise NetError("Username must be 3-20 chars: letters, digits, _ or .")
        if username in self.users:
            raise NetError("Username already taken")
        if len(password or "") < 6:
            raise NetError("Password must be at least 6 characters")
        if not (name or "").strip():
            raise NetError("Name is required")
        salt = os.urandom(16).hex()
        u = User(username, hash_password(password, salt), salt, name.strip(),
                 programme.strip(), self._year(year), bio.strip()[:300],
                 self._skills(skills))
        self.db.run("INSERT INTO users VALUES(?,?,?,?,?,?,?,?)",
                    (u.username, u.pw_hash, u.salt, u.name, u.programme,
                     u.year, u.bio, ",".join(u.skills)))
        self._register(u)
        return u.username

    def login(self, username, password):
        u = self.users.get((username or "").strip().lower())
        # same message for unknown user / wrong password (no user enumeration)
        if not u or not hmac.compare_digest(u.pw_hash, hash_password(password or "", u.salt)):
            raise NetError("Invalid username or password")
        return u.username

    def logout(self, username):
        self.history[username] = Stack()     # clear back-navigation history

    @staticmethod
    def _year(y):
        try:
            y = int(y)
        except (TypeError, ValueError):
            raise NetError("Year must be a number")
        if not 1 <= y <= 6:
            raise NetError("Year must be between 1 and 6")
        return y

    @staticmethod
    def _skills(s):
        if isinstance(s, str):
            s = s.split(",")
        out = []
        for x in s:
            x = x.strip()
            if x and x.lower() not in [o.lower() for o in out]:
                out.append(x[:30])
        return out[:15]

    def update_profile(self, username, name=None, programme=None, year=None,
                       bio=None, skills=None):
        u = self._user(username)
        self._unindex(u)
        if name is not None:
            if not name.strip():
                self._index(u)
                raise NetError("Name is required")
            u.name = name.strip()
        if programme is not None:
            u.programme = programme.strip()
        if year is not None:
            u.year = self._year(year)
        if bio is not None:
            u.bio = bio.strip()[:300]
        if skills is not None:
            u.skills = self._skills(skills)
        self._index(u)
        self.db.run("UPDATE users SET name=?, programme=?, year=?, bio=?, skills=? WHERE username=?",
                    (u.name, u.programme, u.year, u.bio, ",".join(u.skills), username))
        return u.profile()

    def _user(self, username):
        u = self.users.get(username)
        if not u:
            raise NetError(f"User '{username}' not found")
        return u

    # ------------------------------------------------------------------ #
    # Profiles (with stack-based back navigation)
    # ------------------------------------------------------------------ #
    def relation(self, viewer, target):
        if viewer == target:
            return "self"
        if self.graph.has_edge(viewer, target):
            return "connected"
        if target in self.requests_out[viewer]:
            return "pending_out"
        if viewer in self.requests_out[target]:
            return "pending_in"
        return "none"

    def get_profile(self, viewer, target, record=True):
        u = self._user(target)
        if record and self.history[viewer].peek() != target:
            self.history[viewer].push(target)
        d = u.profile()
        d["relation"] = self.relation(viewer, target)
        d["connection_count"] = self.graph.degree(target)
        if viewer != target:
            d["mutual"] = [self.users[m].summary() for m in sorted(self.graph.mutual(viewer, target))]
            d["connection_info"] = self.connection_info(viewer, target)
        return d

    def back(self, viewer):
        """Pop the current profile and return the previous one (or None)."""
        h = self.history[viewer]
        if len(h) < 2:
            return None
        h.pop()
        return self.get_profile(viewer, h.peek(), record=False)

    # ------------------------------------------------------------------ #
    # Part 2: Connections
    # ------------------------------------------------------------------ #
    def send_request(self, sender, receiver):
        self._user(receiver)
        if sender == receiver:
            raise NetError("You cannot connect with yourself")
        if self.graph.has_edge(sender, receiver):
            raise NetError("Already connected")
        if receiver in self.requests_out[sender]:
            raise NetError("Request already sent")
        if sender in self.requests_out[receiver]:
            raise NetError("This user already sent you a request - accept it instead")
        self.requests_in[receiver].enqueue(sender)           # directed edge sender -> receiver
        self.requests_out[sender].add(receiver)
        self.db.run("INSERT INTO requests VALUES(?,?,?)", (sender, receiver, time.time()))
        self._notify(receiver, "request", f"{self.users[sender].name} sent you a connection request")

    def _drop_request(self, sender, receiver):
        self.requests_in[receiver].remove(sender)
        self.requests_out[sender].discard(receiver)
        self.db.run("DELETE FROM requests WHERE sender=? AND receiver=?", (sender, receiver))

    def accept_request(self, receiver, sender):
        if sender not in self.requests_in[receiver]:
            raise NetError("No pending request from that user")
        self._drop_request(sender, receiver)
        self.graph.add_edge(sender, receiver)                # directed edge becomes undirected
        a, b = sorted((sender, receiver))
        self.db.run("INSERT OR IGNORE INTO connections VALUES(?,?)", (a, b))
        self._notify(sender, "accepted", f"{self.users[receiver].name} accepted your connection request")

    def reject_request(self, receiver, sender):
        if sender not in self.requests_in[receiver]:
            raise NetError("No pending request from that user")
        self._drop_request(sender, receiver)

    def cancel_request(self, sender, receiver):
        if receiver not in self.requests_out[sender]:
            raise NetError("You have no pending request to that user")
        self._drop_request(sender, receiver)

    def remove_connection(self, a, b):
        if not self.graph.has_edge(a, b):
            raise NetError("You are not connected")
        self.graph.remove_edge(a, b)
        x, y = sorted((a, b))
        self.db.run("DELETE FROM connections WHERE a=? AND b=?", (x, y))

    def incoming_requests(self, user):
        return [self.users[s].summary() for s in self.requests_in[user]]      # FIFO order

    def outgoing_requests(self, user):
        return [self.users[r].summary() for r in sorted(self.requests_out[user])]

    def connections(self, user):
        return [self.users[c].summary() for c in sorted(self.graph.neighbors(user),
                                                        key=lambda c: self.users[c].name.lower())]

    def mutual_connections(self, a, b):
        self._user(b)
        return [self.users[m].summary() for m in sorted(self.graph.mutual(a, b))]

    def suggestions(self, user, k=10):
        pending = self.requests_out[user] | {s for s in self.requests_in[user]}
        out = []
        for c, score, mutual in self.graph.suggestions(user, k, exclude=pending):
            d = self.users[c].summary()
            d.update({"score": score, "mutual_count": mutual})
            out.append(d)
        return out

    def connection_info(self, a, b):
        """Degree of connection plus one shortest chain (BFS)."""
        if a == b:
            return {"degree": 0, "label": "You", "path": [self.users[a].summary()]}
        path = self.graph.shortest_path(a, b)
        if path is None:
            return {"degree": None, "label": "Not connected", "path": []}
        deg = len(path) - 1
        return {"degree": deg, "label": ordinal(deg) + " degree connection",
                "path": [self.users[p].summary() for p in path]}

    def communities(self, user):
        return [[self.users[m].summary() for m in c]
                for c in self.graph.cliques_containing(user)]

    # ------------------------------------------------------------------ #
    # Part 3: Posts and feed
    # ------------------------------------------------------------------ #
    def create_post(self, user, text, image=None):
        text = (text or "").strip()
        if not text and not image:
            raise NetError("Post cannot be empty")
        if len(text) > 1000:
            raise NetError("Post too long (max 1000 characters)")
        ts = time.time()
        cur = self.db.run("INSERT INTO posts(author,text,image,ts) VALUES(?,?,?,?)",
                          (user, text, image, ts))
        p = Post(cur.lastrowid, user, text, image, ts)
        self.posts[p.id] = p
        self.posts_by_user[user].append(p.id)     # ids/timestamps only grow => list stays sorted
        return self.post_view(p, user)

    def delete_post(self, user, post_id):
        p = self.posts.get(post_id)
        if not p:
            raise NetError("Post not found")
        if p.author != user:
            raise NetError("You can only delete your own posts")
        self.posts_by_user[user].remove(post_id)
        del self.posts[post_id]
        # drop the post's comments
        stack = list(p.comment_ids)
        while stack:
            cid = stack.pop()
            c = self.comments.pop(cid, None)
            if c:
                stack.extend(c.children)
        self.db.run("DELETE FROM posts WHERE id=?", (post_id,))
        self.db.run("DELETE FROM likes WHERE post_id=?", (post_id,))
        self.db.run("DELETE FROM comments WHERE post_id=?", (post_id,))
        return p.image

    def user_posts(self, viewer, target):
        self._user(target)
        return [self.post_view(self.posts[i], viewer) for i in reversed(self.posts_by_user[target])]

    def feed(self, user, limit=30):
        """
        Home feed: merge the time-ordered post lists of all connections.
        k-way merge with a heap. Each connection contributes a pointer to their
        newest post; we pop the global newest, then push that author's next one.
        Cost O(limit * log k) after O(k) setup (k = number of connections).
        """
        heap = []
        for c in self.graph.neighbors(user):
            ids = self.posts_by_user[c]
            if ids:
                i = len(ids) - 1
                p = self.posts[ids[i]]
                heap.append((-p.ts, -p.id, c, i))      # max-heap via negation
        heapq.heapify(heap)
        out = []
        while heap and len(out) < limit:
            _, _, c, i = heapq.heappop(heap)
            out.append(self.post_view(self.posts[self.posts_by_user[c][i]], user))
            if i > 0:
                p = self.posts[self.posts_by_user[c][i - 1]]
                heapq.heappush(heap, (-p.ts, -p.id, c, i - 1))
        return out

    # ---- likes / comments / trending --------------------------------- #
    def toggle_like(self, user, post_id):
        p = self._post(post_id)
        if user in p.likes:
            p.likes.discard(user)
            self.db.run("DELETE FROM likes WHERE post_id=? AND user=?", (post_id, user))
        else:
            p.likes.add(user)
            self.db.run("INSERT OR IGNORE INTO likes VALUES(?,?)", (post_id, user))
            if p.author != user:
                self._notify(p.author, "like", f"{self.users[user].name} liked your post")
        return len(p.likes), user in p.likes

    def add_comment(self, user, post_id, text, parent=0):
        p = self._post(post_id)
        text = (text or "").strip()
        if not text:
            raise NetError("Comment cannot be empty")
        parent = int(parent or 0)
        if parent:
            par = self.comments.get(parent)
            if not par or par.post_id != post_id:
                raise NetError("Parent comment not found")
        ts = time.time()
        cur = self.db.run("INSERT INTO comments(post_id,author,parent_id,text,ts) VALUES(?,?,?,?,?)",
                          (post_id, user, parent or None, text[:500], ts))
        c = Comment(cur.lastrowid, post_id, user, parent, text[:500], ts)
        self.comments[c.id] = c
        if parent:
            self.comments[parent].children.append(c.id)
            target = self.comments[parent].author
        else:
            p.comment_ids.append(c.id)
            target = p.author
        if target != user:
            self._notify(target, "comment", f"{self.users[user].name} commented: {text[:40]}")
        return self._comment_tree(c.id)

    def _comment_tree(self, cid):
        c = self.comments[cid]
        return {"id": c.id, "author": self.users[c.author].summary(), "text": c.text,
                "ts": c.ts, "replies": [self._comment_tree(r) for r in c.children]}

    def trending(self, user, k=5):
        """
        Top-k posts among you + your connections ranked by engagement
        (likes + 2*comments) decayed by age. heapq.nlargest keeps a size-k heap:
        O(n log k).
        """
        now = time.time()
        pool = [user, *self.graph.neighbors(user)]

        def score(p):
            n_comments = self._count_comments(p)
            age_h = (now - p.ts) / 3600
            return (len(p.likes) + 2 * n_comments) / (age_h + 2) ** 1.5

        posts = [self.posts[i] for a in pool for i in self.posts_by_user[a]]
        best = heapq.nlargest(k, posts, key=lambda p: (score(p), p.id))
        return [self.post_view(p, user) for p in best if score(p) > 0]

    def _count_comments(self, p):
        total, stack = 0, list(p.comment_ids)
        while stack:
            c = self.comments[stack.pop()]
            total += 1
            stack.extend(c.children)
        return total

    def _post(self, post_id):
        p = self.posts.get(int(post_id))
        if not p:
            raise NetError("Post not found")
        return p

    def post_view(self, p, viewer):
        return {"id": p.id, "author": self.users[p.author].summary(), "text": p.text,
                "image": p.image, "ts": p.ts, "likes": len(p.likes),
                "liked": viewer in p.likes, "comment_count": self._count_comments(p),
                "comments": [self._comment_tree(c) for c in p.comment_ids],
                "mine": p.author == viewer}

    # ------------------------------------------------------------------ #
    # Notifications
    # ------------------------------------------------------------------ #
    def _notify(self, user, kind, text):
        ts = time.time()
        cur = self.db.run("INSERT INTO notifications(user,kind,text,ts) VALUES(?,?,?,?)",
                          (user, kind, text, ts))
        self.notifs[user].append({"id": cur.lastrowid, "kind": kind, "text": text,
                                  "ts": ts, "read": False})

    def notifications(self, user, mark_read=True):
        items = list(reversed(self.notifs[user][-50:]))      # newest first
        unread = sum(1 for n in self.notifs[user] if not n["read"])
        if mark_read:
            for n in self.notifs[user]:
                n["read"] = True
            self.db.run("UPDATE notifications SET is_read=1 WHERE user=?", (user,))
        return {"unread": unread, "items": items}

    def unread_count(self, user):
        return sum(1 for n in self.notifs[user] if not n["read"])

    # ------------------------------------------------------------------ #
    # Part 4: Search (trie prefix search)
    # ------------------------------------------------------------------ #
    def search(self, prefix, limit=10):
        prefix = (prefix or "").strip().lower()
        if not prefix:
            return []
        return [self.users[v].summary() for v in self.name_index.starts_with(prefix, limit)]
